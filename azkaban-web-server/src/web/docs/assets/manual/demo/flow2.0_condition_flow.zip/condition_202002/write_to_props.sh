echo '{"param1": "20200217"}' > $JOB_OUTPUT_PROP_FILE

