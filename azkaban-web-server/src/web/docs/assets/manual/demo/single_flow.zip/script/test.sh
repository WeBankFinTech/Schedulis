#!/bin/bash
echo "hello world"
exit $?